<p align="center"><img src="https://pixabay.com/static/uploads/photo/2015/03/29/22/06/rwanda-697792_960_720.png" width="200"></p>

### Hi there!   Yes... you!

#####Have you heard of Rwanda? A nation located in the heart of Africa? This guy below is from there. And he goes by Denis Rugira
<p align="center">
 <img src="https://avatars0.githubusercontent.com/u/1365983?v=3&s=460" width="150">
</p>
#####Here's a few interesting facts about Rwanda:

- Rwanda has the world’s highest representation of women in parliament.
- Rwanda is leading Africa’s digital revolution.
- In 2007, Rwanda became the first country in the world to legislate an outright ban on plastic bags.
- Rwanda is one of the cleanest countries in Africa and maybe the world. Why? Rwanda has a community cleaning day on the last Saturday of the month where everyone contributes to cleaning up their neighborhood.


#####Congratulations! You know more about the world than you did a Github repo ago.

***

Now...about the code you are looking for -- read on to find out how to clone and run it on your local machine.



####Project description 
A simple ticket service that facilitates the discovery, temporary hold, and final reservation of seats within a high-demand performance venue.

<p align="left"><img src="https://raw.githubusercontent.com/rugden/TicketService/master/Ticket%20Service%20DFD.png" width="600"></p>


######Feature list
System should provide the ability to 
* find all available seats in a performance venue
* find all available seats in a specific level of a performance veneue
* find and hold the best available seats in a performance venue

######Rules
* A user can have only one seat hold at any given time
* A user must hold a seat before reserving it
* A seat hold is not indefinite. It expires after a configurable amount of time

***

### Importing and running java project on your local machine 
For maven setup instruction visit [Maven Setup](https://maven.apache.org/install.html)

1. **git clone https://github.com/rugden/TicketService.git**  to clone project to local directory
2. Navigate to TicketService directory 
3. From the command line enter **mvn clean install** to build and package the webapp into a war file
4. And **mvn tomcat7:run**  to deploy and run the webapp on an embedded tomcat server. Below is what you should see once the command has run successfully.

<p align="left">
<img src="https://raw.githubusercontent.com/rugden/TicketService/master/mvn%20screen%20shot.PNG" width="800">
</p>

***

#####RESTful API usage 
Web app context path: **http://localhost:8080/TicketService/**
Below are the HTTP methods and URIs used to interact with the Ticket service.
Source code of Resource class is available [here](https://github.com/rugden/TicketService/blob/master/src/main/java/com/rugden/resource/TicketResource.java)
######find all available seats
* GET  *{contextpath}/tickets*  for all available seats

######find available seats by level
* GET  *{contextpath}/tickets/1* for available seats at specific level

######find and hold best available seats where minLevel and maxLevel are optional fields
* POST *{contextpath}/tickets/hold?minLevel=1&maxLevel=1&numSeats=2000&customerEmail=reston@gmail.com*

######Reserve seats
* POST *{contextpath}/tickets/reservation?seatHoldId=1&customerEmail=reston@gmail.com*

***
#####Technologies used
* JUnit and Jersey Test frameworks
* Jersey, JAX-RS implementation
* Google Guava cache
* Embedded Tomcat servlet container
